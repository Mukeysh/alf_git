﻿Themer's Test Kitchen
–––––––––––––––––––––––––––––––––

This collection of files will enable a web designer to create a custom
'theme' for use in the Scholars Web Site Project.

For more information about building your theme, and the underlining CSS
of the project, please see: http://scholar.harvard.edu/help/vsitehelp/
Creating-a-Scholars-Web-Site-theme